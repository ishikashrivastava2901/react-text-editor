import React, { useEffect } from "react";
import '../TextEditor/style.css'
import copy from "copy-to-clipboard";
import { useState } from "react";
const TextEditor = () => {
  const [input, setInput] = useState("");
  const [character, setCharacter] = useState(0);
  const [word, setWord] = useState(0);

  const copyToClipboard = () => {
    copy(input);
    alert(`You have copied "${input}"`);
};

  const countCharacter = () => {
    setCharacter((prevState) => input.length);
  };

  const countWords = () => {
    const words = input.split(/\s+/).filter((word) => word !== "");
    return setWord((prevState) => words.length);
  };

  const upperCaseClick = () => {
    setInput((prevState) => prevState.toUpperCase());
  };

  const lowerCaseClick = () => {
    setInput((prevState) => prevState.toLowerCase());
  };
  const trimClick = () => {
    setInput((prevState) => prevState.trim());
  };

  const removeSpaceClick = () => {
    setInput((prevState) => prevState.replace(/ /g, ""));
  };
  const clearClick = () => {
    setInput("");
    setWord(0);
    setCharacter(0);
  };

  useEffect(() => {
    countCharacter();
    countWords();
  }, [input]);

  return (
    <>
      <nav class='navbar navbar-expand-lg navbar-light bg-light'>
        <div class='container-fluid'>
          <a class='navbar-brand' href='#'>
            TEXT EDITOR
          </a>
          <button
            class='navbar-toggler'
            type='button'
            data-bs-toggle='collapse'
            data-bs-target='#navbarNavAltMarkup'
            aria-controls='navbarNavAltMarkup'
            aria-expanded='false'
            aria-label='Toggle navigation'
          >
            <span class='navbar-toggler-icon'></span>
          </button>
          <div class='collapse navbar-collapse' id='navbarNavAltMarkup'>
            <div class='navbar-nav'>
              <a class='nav-link active' aria-current='page' href='#'>
                <b>Home</b>
              </a>
            </div>
          </div>
        </div>
      </nav>
      <br></br>
      <div className='head'>
        <div className='heading'>
          <h1>
            Simply enter your text and choose the case you want to convert it to
          </h1>
        </div>
        <br></br>
        <div>
          <textarea
            value={input}
            className='text-area'
            placeholder='Leave a comment here'
            onChange={(e) => {
              setInput(e.target.value);
            }}
          ></textarea>
        </div>
        <div className='button'>
          <button
            class='btn btn-primary'
            type='submit'
            onClick={upperCaseClick}
          >
            Upper Case
          </button>
          &nbsp;&nbsp;&nbsp;
          <button
            class='btn btn-primary'
            type='submit'
            onClick={lowerCaseClick}
          >
            Lower Case
          </button>
          &nbsp;&nbsp;&nbsp;
          <button class='btn btn-primary' type='submit' onClick={trimClick}>
            Trim Text
          </button>
          &nbsp;&nbsp;&nbsp;
          <button
            class='btn btn-primary'
            type='submit'
            onClick={removeSpaceClick}
          >
            Remove Extra Spaces
          </button>
          &nbsp;&nbsp;&nbsp;
          <button type='button' class='btn btn-danger' onClick={clearClick}>
            Clear
          </button>
          &nbsp;&nbsp;&nbsp;
          <button type='button' className='btn btn-success' onClick={copyToClipboard}>
            Copy
          </button>
        </div>
        <h2>Text Report</h2>
        <div>
          <p>Character count: {character}</p>
          <p>Word count:{word} </p>
          <p>Minutes takes to read: </p>
        </div>
      </div>
    </>
  );
};

export default TextEditor;
